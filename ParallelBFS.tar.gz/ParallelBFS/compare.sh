echo "Diffing $1 $2"
# sort $1 > temp1
# sort $2 > temp2
diff $1 $2